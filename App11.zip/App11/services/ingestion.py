# services/ingestion.py
import os
import re
import tempfile
from io import BytesIO

import pandas as pd
import streamlit as st

from services.db import get_db

# === Google Drive 相关 ===
from pydrive2.auth import GoogleAuth
from pydrive2.drive import GoogleDrive

import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")
warnings.filterwarnings("ignore", category=pd.errors.DtypeWarning)


FOLDER_ID = "1lPmmJdB75yhDx2j4FxCjBW5iLZH3RQSp"

# ✅ 全局缓存 drive 实例
_drive_instance = None



def get_drive():
    """
    Fully robust Google Drive authentication:
    - Loads credentials.
    - If token expired → try refresh.
    - If refresh fails (invalid_grant) → delete token → force re-auth.
    - Always saves new token.
    """
    global _drive_instance
    if _drive_instance is not None:
        return _drive_instance

    gauth = GoogleAuth()

    # token 保存路径（pydrive2 默认推荐 token.json）
    TOKEN_PATH = "token.json"

    # 如果 token.json 不存在 → 强制首次登录
    if not os.path.exists(TOKEN_PATH):
        st.sidebar.info("🔐 Please sign in to Google Drive.")
        gauth.LocalWebserverAuth()
        gauth.SaveCredentialsFile(TOKEN_PATH)
        _drive_instance = GoogleDrive(gauth)
        return _drive_instance

    # Step 1 — load existing credentials
    if os.path.exists(TOKEN_PATH):
        try:
            gauth.LoadCredentialsFile(TOKEN_PATH)
        except Exception:
            os.remove(TOKEN_PATH)
            gauth.credentials = None

    # Step 2 — If credentials exist, try refresh
    if gauth.credentials is not None:
        try:
            if gauth.access_token_expired:
                gauth.Refresh()
            else:
                gauth.Authorize()

        except Exception as e:
            # refresh failed → invalid_grant → must re-auth
            print("⚠️ Token refresh failed:", e)
            try:
                os.remove(TOKEN_PATH)
            except:
                pass
            gauth.LocalWebserverAuth()

    else:
        # No token at all → first-time login
        gauth.LocalWebserverAuth()

    # Step 3 — Save new token
    gauth.SaveCredentialsFile(TOKEN_PATH)

    _drive_instance = GoogleDrive(gauth)
    return _drive_instance


def upload_file_to_drive(local_path: str, remote_name: str):
    """Upload file to Google Drive with success message."""
    try:
        drive = get_drive()  # now fully robust
        f = drive.CreateFile({'title': remote_name, 'parents': [{'id': FOLDER_ID}]})
        f.SetContentFile(local_path)
        f.Upload()
        st.sidebar.success(f"☁️ Uploaded to Google Drive: {remote_name}")
        return True

    except Exception as e:
        st.sidebar.warning(f"⚠️ Upload to Drive failed: {e}")
        return False


def download_file_from_drive(file_id, local_path):
    drive = get_drive()
    f = drive.CreateFile({'id': file_id})
    f.GetContentFile(local_path)


# --------------- 工具函数 ---------------

def _fix_header(df: pd.DataFrame) -> pd.DataFrame:
    """若第一行是 Unnamed，多数是多行表头；把第二行提为表头。"""
    if len(df.columns) and all(str(c).startswith("Unnamed") for c in df.columns):
        df.columns = df.iloc[0]
        df = df.drop(index=0).reset_index(drop=True)
    return df


def _to_float(series: pd.Series) -> pd.Series:
    return (
        series.astype(str)
        .str.replace(r"[^0-9\.\-]", "", regex=True)
        .replace("", pd.NA)
        .astype(float)
    )


def _extract_date_from_filename(name: str):
    """从文件名中提取 YYYY-MM-DD"""
    m = re.search(r"(\d{4}-\d{2}-\d{2})", name)
    if m:
        return m.group(1)
    return None


# --------------- 预处理（不改列名） ---------------

def preprocess_transactions(df: pd.DataFrame) -> pd.DataFrame:
    df = _fix_header(df)
    if "Date" in df.columns and "Time" in df.columns:
        df["Datetime"] = pd.to_datetime(
            df["Date"].astype(str) + " " + df["Time"].astype(str),
            errors="coerce"
        )
        drop_cols = [c for c in ["Date", "Time", "Time Zone"] if c in df.columns]
        df = df.drop(columns=drop_cols)
    elif "Datetime" in df.columns:
        df["Datetime"] = pd.to_datetime(df["Datetime"], errors="coerce")

    for col in ["Net Sales", "Gross Sales", "Qty", "Discounts"]:
        if col in df.columns:
            df[col] = _to_float(df[col])

    # === 新增：Card Brand 与 PAN Suffix 处理，保证写入数据库 ===
    if "Card Brand" in df.columns:
        df["Card Brand"] = (
            df["Card Brand"]
            .astype(str)
            .str.strip()
            .str.title()  # 标准化为首字母大写
        )

    if "PAN Suffix" in df.columns:
        df["PAN Suffix"] = (
            df["PAN Suffix"]
            .astype(str)
            .str.replace(r"\.0$", "", regex=True)  # 去掉浮点形式的".0"
            .str.strip()
        )
    # === NEW: Clean item names / remove leading '*' ===
    for col in ["Item", "Item Name", "Price Point Name"]:
        if col in df.columns:
            df[col] = (
                df[col]
                .astype(str)
                .str.replace(r'^\*+', '', regex=True)  # remove one or more leading *
                .str.strip()
            )

    # === 自动分类：所有含“kombucha”关键字的项目归类为 Drinks ===

    if "Item" in df.columns and "Category" in df.columns:
        df["Item_lower"] = df["Item"].astype(str).str.lower()

        # 包含任何 "kombucha" 字样的 item → Drinks
        kombucha_mask = df["Item_lower"].str.contains("kombucha", na=False)

        df.loc[kombucha_mask, "Category"] = "Drinks"

        # 删除临时列
        df = df.drop(columns=["Item_lower"])

    return df


def preprocess_inventory(df: pd.DataFrame, filename: str = None) -> pd.DataFrame:
    df = _fix_header(df)

    # inventory表格从第二行开始是header
    if len(df) > 0 and all(str(col).startswith("Unnamed") for col in df.columns):
        df.columns = df.iloc[0]
        df = df[1:].reset_index(drop=True)
        df = _fix_header(df)  # 再次处理可能的多行表头

    # === NEW: Clean leading '*' from Item/Variation columns ===
    for col in ["Item", "Item Name", "Variation Name", "SKU"]:
        if col in df.columns:
            df[col] = (
                df[col]
                .astype(str)
                .str.replace(r'^\*+', '', regex=True)  # 去掉开头的所有星号
                .str.strip()
            )

    required = [
        "Tax - GST (10%)", "Price", "Current Quantity Vie Market & Bar",
        "Default Unit Cost", "Categories"
    ]
    for col in required:
        if col not in df.columns:
            df[col] = None

    # 过滤掉Current Quantity Vie Market & Bar或者Default Unit Cost为空的行
    if "Current Quantity Vie Market & Bar" in df.columns and "Default Unit Cost" in df.columns:
        for col in ["Price", "Current Quantity Vie Market & Bar", "Default Unit Cost"]:
            if col not in df.columns:
                df[col] = None
            df[col] = (
                df[col].astype(str)
                .str.replace(r"[^0-9\.\-]", "", regex=True)
                .replace("", pd.NA)
            )
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    if filename:
        df["source_date"] = _extract_date_from_filename(filename)

    return df


def _is_transaction_file(filename: str, df: pd.DataFrame) -> bool:
    """双重判断：文件名 + 列名 才认为是交易文件"""
    fname = (filename or "").lower()

    # 文件名关键词
    name_ok = (
        "item" in fname or
        "transaction" in fname or
        "sales" in fname
    )

    # 列名关键词
    cols = {str(c).strip().lower() for c in df.columns}
    cols_ok = ("net sales" in cols and "gross sales" in cols)

    return name_ok and cols_ok


def _is_inventory_file(filename: str, df: pd.DataFrame) -> bool:
    """双重判断：文件名 + 列名 才认为是库存文件"""
    fname = (filename or "").lower()

    # 文件名关键词
    name_ok = (
        "catalogue" in fname or
        "inventory" in fname or
        "stock" in fname
    )

    # 列名关键词：至少出现任意一个
    cols = {str(c).strip().lower() for c in df.columns}
    cols_ok = (
        "sku" in cols or
        "categories" in cols or
        "stock on hand" in cols
    )

    return name_ok and cols_ok


def _is_member_file(filename: str, df) -> bool:
    """
    判断一个文件是否为 member 文件：
    - 文件名包含 'member'（不分大小写），或者
    - 列名中同时包含 First Name / Surname / Birthday （不分大小写）
    """
    fname = (filename or "").lower()
    has_member_in_name = "member" in fname

    # df 不是 DataFrame 的时候，不要直接访问 .columns，以免报错
    if not hasattr(df, "columns"):
        # 退一步：如果文件名里写了 member，就当成 member 文件，否则直接 False
        return has_member_in_name

    cols_lower = {str(c).strip().lower() for c in df.columns}
    has_core_cols = {"first name", "surname", "birthday"}.issubset(cols_lower)

    return has_member_in_name or has_core_cols



def preprocess_members(df: pd.DataFrame) -> pd.DataFrame:
    df = _fix_header(df)

    # 1) 标准化列名：全部转小写后做映射
    rename_map = {}
    for c in df.columns:
        cl = str(c).strip().lower()

        if cl == "surname":
            rename_map[c] = "Last Name"
        elif cl == "last name":
            rename_map[c] = "Last Name"
        elif cl == "first name":
            rename_map[c] = "First Name"
        elif cl == "square customer id":
            rename_map[c] = "Square Customer ID"
        elif cl == "email address":
            rename_map[c] = "Email Address"
        elif cl == "phone number":
            rename_map[c] = "Phone Number"
        elif cl == "creation date":
            rename_map[c] = "Creation Date"
        elif cl == "customer note":
            rename_map[c] = "Customer Note"
        elif cl == "reference id":
            rename_map[c] = "Reference ID"

    df = df.rename(columns=rename_map)

    # 2) 清理 Phone Number 字段 - 移除注释文本
    if "Phone Number" in df.columns:
        def clean_phone(phone):
            if pd.isna(phone):
                return phone
            phone_str = str(phone)
            # 查找手机号模式：以+61或61开头
            import re
            match = re.search(r'(\+?61\d{8,9})', phone_str)
            if match:
                return match.group(1)
            # 如果没有找到，返回原始值
            return phone_str

        df["Phone Number"] = df["Phone Number"].apply(clean_phone)

    # 3) 清理 Square Customer ID 和 Reference ID
    for col in ["Square Customer ID", "Reference ID"]:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip()

    # 4) 只保留和 DB 对齐的列
    allowed_cols = [
        "Square Customer ID",
        "First Name",
        "Last Name",
        "Email Address",
        "Phone Number",
        "Creation Date",
        "Customer Note",
        "Reference ID",
    ]
    existing = [c for c in df.columns if c in allowed_cols]
    df = df[existing]

    # 5) 简单清洗：去空格
    for col in ["Square Customer ID", "First Name", "Last Name",
                "Email Address", "Phone Number", "Reference ID"]:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip()

    return df


# --------------- 表结构对齐 & 去重 & 写入 ---------------

def _table_exists(conn, table: str) -> bool:
    try:
        cur = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
        return cur.fetchone() is not None
    except Exception:
        return False


def _existing_columns(conn, table: str) -> list:
    try:
        cur = conn.execute(f"PRAGMA table_info('{table}')")
        return [row[1] for row in cur.fetchall()]
    except Exception:
        return []


def _add_missing_columns(conn, table: str, missing_cols: list, prefer_real: set):
    cur = conn.cursor()
    for col in missing_cols:
        coltype = "REAL" if col in prefer_real else "TEXT"
        cur.execute(f'''ALTER TABLE "{table}" ADD COLUMN "{col}" {coltype}''')
    conn.commit()


def _ensure_table_schema(conn, table: str, df: pd.DataFrame, prefer_real: set):
    if not _table_exists(conn, table):
        # 如果表不存在，创建表
        df.head(0).to_sql(table, conn, if_exists="replace", index=False)
        return
    cols_now = set(_existing_columns(conn, table))
    incoming = list(df.columns)
    missing = [c for c in incoming if c not in cols_now]
    if missing:
        _add_missing_columns(conn, table, missing, prefer_real)


def _deduplicate(df: pd.DataFrame, key_col: str, conn, table: str) -> pd.DataFrame:
    if df is None or df.empty:
        return df

    if table == "inventory" and "source_date" in df.columns and "SKU" in df.columns:
        try:
            # 只与同一天的数据去重
            exist = pd.read_sql('SELECT source_date, SKU FROM "inventory"', conn)
            exist["source_date"] = pd.to_datetime(exist["source_date"], errors="coerce").dt.date.astype(str)
            exist["SKU"] = exist["SKU"].astype(str)

            df_local = df.copy()
            df_local["source_date"] = pd.to_datetime(df_local["source_date"], errors="coerce").dt.date.astype(str)
            df_local["SKU"] = df_local["SKU"].astype(str)

            # ✅ 只与相同日期比对，而非所有日期
            existed_keys = set((exist["source_date"] + "||" + exist["SKU"]).unique())
            keys = df_local["source_date"] + "||" + df_local["SKU"]

            mask = ~keys.isin(existed_keys)
            return df_local[mask]
        except Exception:
            return df

    # 其它表/场景：保持原单键去重逻辑
    if key_col not in df.columns:
        return df
    try:
        exist = pd.read_sql(f'''SELECT "{key_col}" FROM "{table}"''', conn)
        existed_set = set(exist[key_col].dropna().astype(str).unique())
        mask = ~df[key_col].astype(str).isin(existed_set)
        return df[mask]
    except Exception:
        return df



def _write_df(conn, df: pd.DataFrame, table: str, key_candidates: list, prefer_real: set):
    """
    统一写入数据库，加入 inventory 特殊逻辑和 members 的增量更新逻辑
    """

    # --- 通用：确保表结构一致 ---
    _ensure_table_schema(conn, table, df, prefer_real)

    # ----------------------------------------------------------------------
    # 🔥 处理 inventory：同一天的记录先删除再写入（你原来的逻辑）
    # ----------------------------------------------------------------------
    if table == "inventory" and "source_date" in df.columns:
        dates = df["source_date"].dropna().unique().tolist()
        if dates:
            for d in dates:
                conn.execute(f'DELETE FROM "{table}" WHERE source_date=?', (d,))
            conn.commit()

    # ----------------------------------------------------------------------
    # 🔥 处理 members：增删改，不整表删除
    # ----------------------------------------------------------------------
    if table == "members":
        # 1) 读取旧数据
        try:
            df_old = pd.read_sql('SELECT * FROM "members"', conn)
        except Exception:
            df_old = pd.DataFrame()

        # 2) 确定 key
        key = None
        for k in ["Square Customer ID", "Reference ID"]:
            if k in df.columns:
                key = k
                break

        if key is None:
            # 如果没有 key，无法对比 → 不写
            return

        # 转换 key 为字符串格式，避免 float/None 问题
        df[key] = df[key].astype(str)
        if not df_old.empty:
            df_old[key] = df_old[key].astype(str)

        old_keys = set(df_old[key]) if not df_old.empty else set()
        new_keys = set(df[key])

        # ------------------------------------------------------------------
        # ① 删除：旧表有，新文件没有
        # ------------------------------------------------------------------
        keys_to_delete = old_keys - new_keys
        if keys_to_delete:
            placeholders = ",".join(["?"] * len(keys_to_delete))
            conn.execute(
                f'DELETE FROM "members" WHERE "{key}" IN ({placeholders})',
                tuple(keys_to_delete)
            )

        # ------------------------------------------------------------------
        # ② 新增：新文件有，旧表没有
        # ------------------------------------------------------------------
        keys_to_insert = new_keys - old_keys
        df_insert = df[df[key].isin(keys_to_insert)]
        if not df_insert.empty:
            df_insert.to_sql("members", conn, if_exists="append", index=False)

        # ------------------------------------------------------------------
        # ③ 更新：ID 相同但字段不同
        # ------------------------------------------------------------------
        if not df_old.empty:
            df_merge = df.merge(df_old, on=key, how="inner", suffixes=("_new", "_old"))
            update_cols = [c for c in df.columns if c != key]

            for _, row in df_merge.iterrows():
                changed = any(str(row[f"{c}_new"]) != str(row[f"{c}_old"]) for c in update_cols)
                if changed:
                    set_clause = ", ".join([f'"{c}"=?' for c in update_cols])
                    params = [row[f"{c}_new"] for c in update_cols] + [row[key]]
                    conn.execute(
                        f'UPDATE members SET {set_clause} WHERE "{key}"=?',
                        params
                    )

        conn.commit()
        return  # members 结束，不走后面的通用逻辑

    # ----------------------------------------------------------------------
    # 🔥 其他表（transactions / inventory）：使用原来的去重逻辑
    # ----------------------------------------------------------------------
    key_col = next((k for k in key_candidates if k in df.columns), None)
    if key_col:
        df = _deduplicate(df, key_col, conn, table)

    if not df.empty:
        df.to_sql(table, conn, if_exists="append", index=False)



# --------------- 索引 ---------------
def ensure_indexes():
    conn = get_db()
    cur = conn.cursor()

    # 确保表存在
    for table in ["transactions", "inventory", "members"]:
        if not _table_exists(conn, table):
            # 如果表不存在，创建空表
            pd.DataFrame().to_sql(table, conn, if_exists="replace", index=False)

    cur.execute('CREATE INDEX IF NOT EXISTS idx_txn_datetime ON transactions(Datetime)')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_txn_id ON transactions([Transaction ID])')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_member_square ON members([Square Customer ID])')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_member_ref ON members([Reference ID])')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_inv_sku ON inventory(SKU)')
    conn.commit()


# --------------- 从 Google Drive 导入 ---------------
def ingest_from_drive_all():
    conn = get_db()

    # 确保表存在
    ensure_indexes()

    drive = get_drive()
    files = drive.ListFile({'q': f"'{FOLDER_ID}' in parents and trashed=false"}).GetList()
    if not files:
        return

    seen = set()
    error_files = []  # 记录哪些文件失败了

    for f in files:
        name = f["title"]
        if name in seen:
            continue
        seen.add(name)

        local = os.path.join(tempfile.gettempdir(), name)

        try:
            # ------------ 下载文件 ------------
            f.GetContentFile(local)

            # ------------ 读入 DataFrame ------------
            if name.lower().endswith(".csv"):
                df = pd.read_csv(local)
                df = _fix_header(df)
            elif name.lower().endswith(".xlsx"):
                header_row = 1 if "catalogue" in name.lower() else 0
                df = pd.read_excel(local, header=header_row)
                df = _fix_header(df)
            else:
                # 不认识的格式，直接跳过
                st.sidebar.warning(f"⚠️ Skip unsupported file: {name}")
                continue

            # ------------ 判断类型 & 写入 DB ------------
            if _is_transaction_file(name, df):
                df = preprocess_transactions(df)
                _write_df(
                    conn,
                    df,
                    "transactions",
                    key_candidates=["Transaction ID", "Item", "Price", "Modifiers Applied"],
                    prefer_real={"Net Sales", "Gross Sales", "Qty", "Discounts"},
                )
                st.sidebar.info(f"📥 Imported transactions from {name}")

            elif _is_inventory_file(name, df):
                df = preprocess_inventory(df, filename=name)
                _write_df(
                    conn,
                    df,
                    "inventory",
                    key_candidates=["SKU"],
                    prefer_real=set(),
                )
                st.sidebar.info(f"📥 Imported inventory from {name}")


            elif _is_member_file(name, df):

                try:

                    df_members = preprocess_members(df)

                    _write_df(

                        conn,

                        df_members,

                        "members",

                        key_candidates=["Square Customer ID", "Reference ID"],

                        prefer_real=set(),

                    )

                    st.sidebar.info(f"📥 Imported members from {name}")

                except Exception as e:

                    # 不要让 members 的问题影响其它文件

                    error_files.append((name, str(e)))

                    st.sidebar.error(f"❌ Failed to import members from {name}: {e}")

                st.sidebar.info(f"📥 Imported members from {name}")

            else:
                # 列结构不匹配，跳过
                st.sidebar.warning(f"⚠️ Schema not recognized, skipped: {name}")

        except Exception as e:
            # ❗单个文件失败不会影响后面文件
            msg = str(e)
            error_files.append((name, msg))
            st.sidebar.error(f"❌ Failed to import {name}: {msg}")

        finally:
            # 删除本地临时文件
            try:
                if os.path.exists(local):
                    os.remove(local)
            except Exception:
                pass

    # 统一再建一次索引
    ensure_indexes()

    # 如果有失败的文件，在 sidebar 打一个汇总提示
    if error_files:
        st.sidebar.warning("⚠️ Some Drive files were skipped when building database:")
        for fname, msg in error_files:
            # 只显示简短错误信息，太长可以只留文件名
            st.sidebar.write(f"• {fname}")

def init_db_from_drive_once():
    try:
        # 首先确保表存在
        ensure_indexes()

        # 检查是否有数据，如果没有则从Drive导入
        conn = get_db()
        cur = conn.cursor()

        try:
            cur.execute("SELECT COUNT(*) FROM transactions")
            tx_count = cur.fetchone()[0]

            cur.execute("SELECT COUNT(*) FROM inventory")
            inv_count = cur.fetchone()[0]

            if tx_count == 0 and inv_count == 0:
                # 只有两个表都为空时才从Drive导入
                ingest_from_drive_all()
        except Exception as e:
            # 如果查询失败，说明表可能不存在，从Drive导入
            ingest_from_drive_all()

    except Exception as e:
        st.sidebar.warning(f"⚠️ Auto-ingest from Drive failed: {e}")
    return True


# --------------- 手动导入（Sidebar 上传） ---------------
def ingest_csv(uploaded_file):
    conn = get_db()

    # 确保表存在
    ensure_indexes()

    filename = uploaded_file.name if hasattr(uploaded_file, "name") else "uploaded.csv"
    st.sidebar.info(f"📂 Importing {filename}")

    try:
        df = pd.read_csv(uploaded_file)
        df = _fix_header(df)

        rows_imported = 0

        if _is_transaction_file(filename, df):
            df = preprocess_transactions(df)
            _write_df(conn, df, "transactions",
                      key_candidates=["Transaction ID"],
                      prefer_real={"Net Sales", "Gross Sales", "Qty", "Discounts"})
            rows_imported = len(df)
            st.sidebar.success(f"✅ Imported {rows_imported} rows (transactions)")

        elif _is_inventory_file(filename, df):
            df = preprocess_inventory(df, filename=filename)
            _write_df(conn, df, "inventory",
                      key_candidates=["SKU"], prefer_real=set())
            rows_imported = len(df)
            st.sidebar.success(f"✅ Imported {rows_imported} rows (inventory)")

        elif _is_member_file(filename, df):
            df = preprocess_members(df)
            _write_df(conn, df, "members",
                      key_candidates=["Square Customer ID", "Reference ID"], prefer_real=set())
            rows_imported = len(df)
            st.sidebar.success(f"✅ Imported {rows_imported} rows (members)")

        else:
            st.sidebar.warning(f"⚠️ Skipped {filename}, schema not recognized")
            return False

        # 上传到 Google Drive
        tmp_path = os.path.join(tempfile.gettempdir(), filename)
        with open(tmp_path, "wb") as f_local:
            if hasattr(uploaded_file, "getbuffer"):
                f_local.write(uploaded_file.getbuffer())
            else:
                f_local.write(uploaded_file.read())
        # === 防止重复上传到 Google Drive ===
        uploaded_drive_files = st.session_state.get("uploaded_drive_files", set())
        if filename not in uploaded_drive_files:
            upload_file_to_drive(tmp_path, filename)
            uploaded_drive_files.add(filename)
        st.session_state["uploaded_drive_files"] = uploaded_drive_files

        # 确保索引创建
        ensure_indexes()

        return True

    except Exception as e:
        st.sidebar.error(f"❌ Error importing {filename}: {str(e)}")
        return False
    finally:
        try:
            if 'tmp_path' in locals():
                os.remove(tmp_path)
        except Exception:
            pass


def ingest_excel(uploaded_file):
    conn = get_db()
    ensure_indexes()

    filename = uploaded_file.name if hasattr(uploaded_file, "name") else "uploaded.xlsx"
    st.sidebar.info(f"📂 Importing {filename}")

    try:
        data = uploaded_file.read()
        xls = pd.ExcelFile(BytesIO(data))

        total_rows_imported = 0

        is_catalogue = ("catalogue" in filename.lower())
        # 只处理 Items/首个 sheet（库存）
        if is_catalogue:
            target_sheets = []
            if "Items" in xls.sheet_names:
                target_sheets = ["Items"]
            else:
                # 回退：找第一个 sheet
                target_sheets = [xls.sheet_names[0]]

            inv_frames = []
            for sheet in target_sheets:
                df = pd.read_excel(xls, sheet_name=sheet, header=1)
                df = _fix_header(df)
                if ("SKU" in df.columns) or ("Stock on Hand" in df.columns) or ("Categories" in df.columns):
                    df = preprocess_inventory(df, filename=filename)
                    inv_frames.append(df)

            if inv_frames:
                inv_all = pd.concat(inv_frames, ignore_index=True)
                _write_df(conn, inv_all, "inventory",
                          key_candidates=["SKU"], prefer_real=set())
                total_rows_imported += len(inv_all)
        else:
            # 非 catalogue 的 Excel：保留原逻辑（逐 sheet 导入）
            for sheet in xls.sheet_names:
                header_row = 0
                df = pd.read_excel(xls, sheet_name=sheet, header=header_row)
                df = _fix_header(df)

                if _is_transaction_file(filename, df):
                    df = preprocess_transactions(df)
                    _write_df(conn, df, "transactions",
                              key_candidates=["Transaction ID"],
                              prefer_real={"Net Sales", "Gross Sales", "Qty", "Discounts"})
                    total_rows_imported += len(df)

                elif _is_inventory_file(filename, df):
                    df = preprocess_inventory(df, filename=filename)
                    _write_df(conn, df, "inventory",
                              key_candidates=["SKU"], prefer_real=set())
                    total_rows_imported += len(df)

                elif _is_member_file(filename, df):
                    df = preprocess_members(df)
                    _write_df(conn, df, "members",
                              key_candidates=["Square Customer ID", "Reference ID"], prefer_real=set())
                    total_rows_imported += len(df)

        st.sidebar.success(f"✅ {filename} imported - {total_rows_imported} total rows")

        # 上传到 Drive（保持原逻辑）
        tmp_path = os.path.join(tempfile.gettempdir(), filename)
        with open(tmp_path, "wb") as f_local:
            f_local.write(data)
        # === 防止重复上传到 Google Drive ===
        uploaded_drive_files = st.session_state.get("uploaded_drive_files", set())
        if filename not in uploaded_drive_files:
            upload_file_to_drive(tmp_path, filename)
            uploaded_drive_files.add(filename)
        st.session_state["uploaded_drive_files"] = uploaded_drive_files

        ensure_indexes()
        return True

    except Exception as e:
        st.sidebar.error(f"❌ Error importing {filename}: {str(e)}")
        return False
    finally:
        try:
            if 'tmp_path' in locals():
                os.remove(tmp_path)
        except Exception:
            pass


__all__ = [
    "ingest_csv",
    "ingest_excel",
    "ingest_from_drive_all",
    "get_drive",
    "upload_file_to_drive",
    "download_file_from_drive",
    "init_db_from_drive_once",
]