import streamlit as st
from datetime import datetime, timedelta, date
import pandas as pd

st.set_page_config(
    page_title="Vie Manly Analytics",
    layout="wide",
    initial_sidebar_state="auto"
)

import warnings
warnings.filterwarnings("ignore", category=FutureWarning)

import os
import pandas as pd
from services.analytics import load_all
from services.db import get_db
from services.ingestion import ingest_excel, ingest_csv, init_db_from_drive_once
from charts.high_level import show_high_level
from charts.sales_report import show_sales_report
from charts.inventory import show_inventory
from charts.product_mix_only import show_product_mix_only
from charts.customer_segmentation import show_customer_segmentation
from init_db import init_db
import subprocess
import sys
from services.ingestion import ingest_from_drive_all
import platform
import numpy as np
from datetime import datetime, timedelta

import psutil

def check_memory():
    mem = psutil.virtual_memory()
    used_gb = mem.used / (1024 ** 3)
    total_gb = mem.total / (1024 ** 3)
    usage_ratio = used_gb / total_gb

    if usage_ratio > 0.85:
        st.warning(f"⚠️ Memory usage high ({usage_ratio*100:.1f}%). Please refresh occasionally.")



# 关闭文件监控，避免 Streamlit Cloud 报 inotify 错误
os.environ["WATCHDOG_DISABLE_FILE_WATCH"] = "true"

# ✅ 确保 SQLite 文件和表结构存在
init_db()  # 必须先初始化数据库表结构

if "drive_initialized" not in st.session_state:
    init_db_from_drive_once()
    st.session_state.drive_initialized = True


st.markdown("<h1 style='font-size:26px; font-weight:700;'>📊 Vie Manly Dashboard</h1>", unsafe_allow_html=True)


# ✅ 缓存数据库加载
@st.cache_data(show_spinner="loading...")
def load_db_cached(days=365):
    db = get_db()
    return load_all(db=db)


def check_missing_data(tx, inv):
    """
    分开检查交易和库存的缺失日期：

    - 交易（transactions）：
        * 从固定的起始日期 tx_start_date 开始（你可以根据需要改）
        * 到今天为止，每一天如果在数据库里完全没有交易记录，就标记为缺失

    - 库存（inventory）：
        * 从固定的起始日期 inv_start_date 开始（你明确说要从 2025-11-01）
        * 到今天为止，每一天如果在数据库里没有任何 inventory 记录，就标记为缺失
    """
    missing_info = {
        "transaction_dates": [],
        "inventory_dates": [],
    }

    today = datetime.now().date()

    # ===== 1. 交易缺失检查 =====
    # 如果你以后想改成从 2024-01-01 开始检测，可以把下面这行改成 date(2024, 1, 1)
    tx_start_date = date(2024, 1, 1)

    if tx is not None and not tx.empty and "Datetime" in tx.columns:
        # 把 Datetime 列安全地转成日期
        tx_dates_series = pd.to_datetime(tx["Datetime"], errors="coerce").dt.date
        tx_dates = set(d for d in tx_dates_series.dropna())

        # 只在 tx_start_date ~ today 这个区间内检查
        if tx_start_date <= today:
            all_days = [
                tx_start_date + timedelta(days=i)
                for i in range((today - tx_start_date).days + 1)
            ]
            missing_tx = [d for d in all_days if d not in tx_dates]
            missing_info["transaction_dates"] = missing_tx

    # ===== 2. 库存缺失检查 =====
    # 按你的要求：inventory 固定从 2025-11-01 往后检查
    inv_start_date = date(2025, 11, 1)

    if inv is not None and not inv.empty and "source_date" in inv.columns:
        inv_dates_series = pd.to_datetime(inv["source_date"], errors="coerce").dt.date
        inv_dates = set(d for d in inv_dates_series.dropna())

        if inv_start_date <= today:
            all_days = [
                inv_start_date + timedelta(days=i)
                for i in range((today - inv_start_date).days + 1)
            ]
            missing_inv = [d for d in all_days if d not in inv_dates]
            missing_info["inventory_dates"] = missing_inv

    return missing_info


# === 数据加载 ===
if "db_cache" not in st.session_state:
    st.session_state.db_cache = load_db_cached()
tx, mem, inv = st.session_state.db_cache


# === Sidebar ===
st.sidebar.header("⚙️ Settings")

# === 数据缺失预警 ===
missing_data = check_missing_data(tx, inv)

if missing_data['transaction_dates'] or missing_data['inventory_dates']:
    st.sidebar.markdown("---")
    st.sidebar.markdown("### ⚠️ Data missing warning")

    if missing_data['transaction_dates']:
        st.sidebar.error("**Missing transaction date:**")
        # 显示最近7天的缺失日期，其他的折叠显示
        recent_missing = sorted(missing_data['transaction_dates'])[-7:]
        for date in recent_missing:
            st.sidebar.write(f"📅 {date.strftime('%Y-%m-%d')}")

        if len(missing_data['transaction_dates']) > 7:
            with st.sidebar.expander(f"check all {len(missing_data['transaction_dates'])} missing dates"):
                for date in sorted(missing_data['transaction_dates']):
                    st.write(f"📅 {date.strftime('%Y-%m-%d')}")

    if missing_data['inventory_dates']:
        st.sidebar.warning("**Missing inventory date:**")
        # 显示最近7天的缺失日期，其他的折叠显示
        recent_missing = sorted(missing_data['inventory_dates'])[-7:]
        for date in recent_missing:
            st.sidebar.write(f"📦 {date.strftime('%Y-%m-%d')}")

        if len(missing_data['inventory_dates']) > 7:
            with st.sidebar.expander(f"check all {len(missing_data['inventory_dates'])} missing dates"):
                for date in sorted(missing_data['inventory_dates']):
                    st.write(f"📦 {date.strftime('%Y-%m-%d')}")

import hashlib

# 文件上传 - 用内容指纹去重（同名但内容更新也会重新导入）
if "uploaded_file_keys" not in st.session_state:
    st.session_state.uploaded_file_keys = set()

uploaded_files = st.sidebar.file_uploader(
    "Upload files",
    type=["csv", "xlsx"],
    accept_multiple_files=True
)

def _file_fingerprint(f) -> str:
    # UploadedFile 支持 getvalue()，同名不同内容会有不同 hash
    content = f.getvalue()
    h = hashlib.sha1(content).hexdigest()
    size = getattr(f, "size", len(content))
    return f"{f.name}::{size}::{h}"

if uploaded_files:
    new_files_uploaded = False

    for f in uploaded_files:
        key = _file_fingerprint(f)

        if key in st.session_state.uploaded_file_keys:
            st.sidebar.warning(f"⚠️ {f.name} already uploaded (same content)")
            continue

        try:
            if f.name.lower().endswith(".xlsx"):
                ok = ingest_excel(f)
            elif f.name.lower().endswith(".csv"):
                ok = ingest_csv(f)
            else:
                ok = False

            if ok:
                new_files_uploaded = True
                st.session_state.uploaded_file_keys.add(key)
                st.sidebar.info(f"📥 Processed: {f.name}")
            else:
                st.sidebar.error(f"❌ Import failed: {f.name}")

        except Exception as e:
            st.sidebar.error(f"❌ Error processing {f.name}: {e}")

    if new_files_uploaded:
        st.sidebar.success("✅ Files ingested & uploaded to Google Drive.")
        load_db_cached.clear()
        st.session_state.db_cache = load_db_cached()
        st.rerun()

# === 清空数据库（强力版） ===
if st.sidebar.button("🗑️ Clear Database"):
    conn = get_db()
    cur = conn.cursor()

    # 1. 清空核心业务表
    for table in ["transactions", "inventory", "members"]:
        try:
            cur.execute(f'DELETE FROM "{table}"')
        except Exception:
            pass
    conn.commit()

    # 2. 清空 Streamlit 缓存
    st.cache_data.clear()
    st.cache_resource.clear()
    load_db_cached.clear()

    # 3. 清理和数据相关的 session_state
    for key in [
        "db_cache",
        "uploaded_file_keys",  # ✅ 改这里
        "uploaded_drive_files",
        "drive_initialized",
        "drive_import_errors",
        "reloaded",
    ]:

        if key in st.session_state:
            del st.session_state[key]

    st.sidebar.success("✅ Database & cache cleared!")
    st.rerun()


# === 重启并从 Google Drive 重建数据库 ===
if st.sidebar.button("🔄 Restart & Rebuild from Google Drive"):
    try:
        # 0. 先清空三张主表（保证重建是从空开始）
        conn = get_db()
        cur = conn.cursor()
        for table in ["transactions", "inventory", "members"]:
            try:
                cur.execute(f'DELETE FROM "{table}"')
            except Exception:
                pass
        conn.commit()

        # 1. 清除所有缓存
        st.cache_data.clear()
        st.cache_resource.clear()
        load_db_cached.clear()

        # 2. 清 session_state 中和数据相关的状态
        for key in [
            "db_cache",
            "uploaded_file_keys",  # ✅ 改这里
            "uploaded_drive_files",
            "drive_initialized",
            "drive_import_errors",
            "reloaded",
        ]:
            if key in st.session_state:
                del st.session_state[key]

        # 3. 从 Google Drive 全量重新导入
        st.sidebar.info("🔄 Rebuilding database from Google Drive...")
        ingest_from_drive_all()

        # 4. 重新加载数据到缓存
        st.session_state.db_cache = load_db_cached()
        tx, mem, inv = st.session_state.db_cache

        st.sidebar.success("✅ Database rebuilt from Google Drive!")
        st.rerun()

    except Exception as e:
        st.sidebar.error(f"❌ Restart failed: {e}")


# === 单位选择 ===
st.sidebar.subheader("📏 Units")

if inv is not None and not inv.empty and "Unit" in inv.columns:
    units_available = sorted(inv["Unit"].dropna().unique().tolist())
else:
    units_available = ["Gram 1.000", "Kilogram 1.000", "Milligram 1.000"]

conn = get_db()
try:
    rows = conn.execute("SELECT name FROM units").fetchall()
    db_units = [r[0] for r in rows]  # 修复这里的索引错误
except Exception:
    db_units = []

all_units = sorted(list(set(units_available + db_units)))
unit = st.sidebar.selectbox("Choose unit", all_units)

new_unit = st.sidebar.text_input("Add new unit")
if st.sidebar.button("➕ Add Unit"):
    if new_unit and new_unit not in all_units:
        conn.execute("CREATE TABLE IF NOT EXISTS units (name TEXT UNIQUE)")
        conn.execute("INSERT OR IGNORE INTO units (name) VALUES (?)", (new_unit,))
        conn.commit()
        st.sidebar.success(f"✅ Added new unit: {new_unit}")
        st.rerun()

# === Section 选择 ===
section = st.sidebar.radio("📂 Sections", [
    "High Level report",
    "Sales report by category",
    "Inventory",
    "product mix",
    "Customers insights"
])

# === 主体展示 ===
if section == "High Level report":
    show_high_level(tx, mem, inv)
elif section == "Sales report by category":
    show_sales_report(tx, inv)
elif section == "Inventory":
    show_inventory(tx, inv)
elif section == "product mix":
    show_product_mix_only(tx)
elif section == "Customers insights":
    show_customer_segmentation(tx, mem)